# Purfose of this file it to copy empty sessions/ directory while making a new distribution.
# If there were no file in sessions/ it wouldn't be copied.
